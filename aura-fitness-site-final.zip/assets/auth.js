
(function () {
  const STORAGE_KEY = "auraFitnessUser";

  function getUser() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY));
    } catch (e) {
      return null;
    }
  }

  function setUser(user) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
  }

  function clearUser() {
    localStorage.removeItem(STORAGE_KEY);
  }

  function initials(name) {
    if (!name) return "U";
    return name
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map(function (part) { return part.charAt(0).toUpperCase(); })
      .join("");
  }

  function renderAuth() {
    const authBox = document.querySelector('.auth-actions');
    if (!authBox) return;

    const user = getUser();
    if (user && user.name) {
      authBox.innerHTML = `
        <div class="user-chip">
          <strong>${user.name}</strong>
        </div>
        <a class="btn-nav btn-outline" href="profile.html">Profile Git</a>
        <button class="btn-nav logout-btn" type="button" id="logoutBtn">Çıkış Yap</button>
      `;

      const logoutBtn = document.getElementById('logoutBtn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
          clearUser();
          window.location.href = 'index.html';
        });
      }
    } else {
      authBox.innerHTML = `
        <a class="btn-nav" href="login.html">Giriş Yap</a>
        <a class="btn-nav" href="register.html">Kayıt Ol</a>
      `;
    }
  }

  function setupRegister() {
    const form = document.getElementById('registerForm');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const name = document.getElementById('registerName').value.trim();
      const email = document.getElementById('registerEmail').value.trim();
      const phone = document.getElementById('registerPhone').value.trim();
      const password = document.getElementById('registerPassword').value.trim();
      const result = document.getElementById('registerResult');

      if (!name || !email || !phone || !password) {
        result.style.display = 'block';
        result.innerHTML = 'Lütfen tüm alanları doldurun.';
        return;
      }

      const user = {
        name: name,
        email: email,
        phone: phone,
        password: password,
        memberSince: new Date().toLocaleDateString('tr-TR')
      };

      setUser(user);
      result.style.display = 'block';
      result.innerHTML = 'Kayıt başarılı ✔️ Yönlendiriliyorsunuz...';
      setTimeout(function () {
        window.location.href = 'profile.html';
      }, 900);
    });
  }

  function setupLogin() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value.trim();
      const result = document.getElementById('loginResult');
      const saved = getUser();

      if (!email || !password) {
        result.style.display = 'block';
        result.innerHTML = 'Lütfen e-posta ve şifre girin.';
        return;
      }

      if (!saved) {
        result.style.display = 'block';
        result.innerHTML = 'Önce kayıt olmanız gerekiyor.';
        return;
      }

      if (saved.email !== email || saved.password !== password) {
        result.style.display = 'block';
        result.innerHTML = 'E-posta veya şifre hatalı.';
        return;
      }

      setUser(saved);
      result.style.display = 'block';
      result.innerHTML = 'Giriş başarılı ✔️ Yönlendiriliyorsunuz...';
      setTimeout(function () {
        window.location.href = 'profile.html';
      }, 800);
    });
  }

  function setupProfile() {
    const profileName = document.getElementById('profileName');
    if (!profileName) return;

    const user = getUser();
    if (!user) {
      window.location.href = 'login.html';
      return;
    }

    document.getElementById('profileName').textContent = user.name || '-';
    document.getElementById('profileEmail').textContent = user.email || '-';
    document.getElementById('profilePhone').textContent = user.phone || '-';
    document.getElementById('profileDate').textContent = user.memberSince || '-';
  }

  document.addEventListener('DOMContentLoaded', function () {
    renderAuth();
    setupRegister();
    setupLogin();
    setupProfile();
  });
})();
